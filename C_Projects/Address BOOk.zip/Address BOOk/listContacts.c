

#include "addressBook.h"

int list_contacts(char * fpc)
{
	contacts cont;

	//open file in read mode
	FILE *fp;
	if((fp = fopen(fpc, "r")) == NULL)
    {
    	FILE_ERROR(fpc);    //if can't open file
        exit(3);
     }


	int contactNos = 1;			//contact count

	printf("Contact details available-\n");
    printf("-------------------------------------------------------------------------------\n");
    printf( "%7s\t\t%-15s\t\t %10s\t %s\n" , "CONTACT", "  Name", " Phone No", "Email Id");
    printf("-------------------------------------------------------------------------------\n");
	while(fread(&cont, sizeof(cont), 1, fp) == 1)
	{
		printf("%1d\t\t %-15s\t %-10s\t %s\n", contactNos, cont.name, cont.phNo, cont.emailId);
		contactNos++;
	}
    printf("-------------------------------------------------------------------------------\n");
	if(1 == contactNos)
	{
		printf("no contacts in file\n");
		return -1;
	}
	
	//close file
	fclose(fp);

	return 1;
}