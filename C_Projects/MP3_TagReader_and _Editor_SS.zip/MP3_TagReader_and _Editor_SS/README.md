# mp3-TagReader
Project Brief: MP3 tag reader is a software which will read and display MP3 (ID3) tag information from MP3 files. The software will be desktop based and not web based. All operations will be performed using command line interface The application would be useful to individuals who wish to view and collect mp3 tag data. This project can be extended to implement a tag editor, wherein users can modify mp3 tag information.  Technologies Used: Embedded C – File operations, Pointers, Bit wise operations, Functions, Make files, Command line arguments

Technologies Used: Embedded C – File operations, Pointers, Bit wise operations, Functions, Make files, Command line arguments
