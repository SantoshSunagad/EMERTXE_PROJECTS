#ifndef MAIN_H
#define MAIN_H

typedef struct Student
{
    char rollNo[4];
    char firstName[50];
    char lastName[50];
    char standard[3];
    char class[2];
    char email[40];
    char attendance[3];
} Student;

void AddDatabase();
void displayInfo();
void updateInfo();
void deleteInfo();
void searchInfo();
void Create_Standard_wise_file();
void save();
void Fill_the_presence_or_absence();
void create_file_present_students_in_school();

#endif