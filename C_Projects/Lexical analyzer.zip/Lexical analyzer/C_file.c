#include <stdio.h>
int main()
{
	int x = 5;
	printf("Hello world\n");
	return 0;
}
