/*
Name : Santosh Ramesh Sunagad
Date : 29/03/2024
Project : Lexical analyzer
Description :
            Project brief Lexical Analyzer is a program which converts the stream of individual
            characters, normally arranged as lines into the stream of lexical tokens.
            Tokenization for instance of words and punctuation symbols that make up
            source code. The main purpose/goal of the project is to take in a C file and
            produce the sequence of tokens that can be used for the next stage in
            compilation.
            This should also take care of necessary error handling conditions that may
            occur during tokenization.
Technologies used :
             File I/O operations
             File pointers
             String operations

Usage : gcc main.c lex.c
        ./a.exe C_file.c

*/

#include "main.h"

int main(int argc, char *argv[])
{
    if (read_and_validation(argv) == e_success)
    {
        printf("Parsing\t: %s : Started\n\n", argv[1]);
        if (lex_analyzer(argv) == e_success)
        {
            printf("\nParsing\t: %s : Done\n\n", argv[1]);
        }
        else
        {
            printf("\nParsing\t: %s : incomplete\n\n", argv[1]);
        }
    }
    else
    {
        printf("Error: \tInvalid Argument\n");
        printf("Usage: \t~/ ./a.out <.c file>\n");
    }

    return 0;
}