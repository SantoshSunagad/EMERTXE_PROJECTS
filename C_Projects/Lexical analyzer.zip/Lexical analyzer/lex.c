#include "main.h"

status read_and_validation(char *argv[])
{
    if (argv[1] != NULL)
    {

        fptr = fopen(argv[1], "r");
        if (fptr == NULL)
        {
            printf("Unable to open file\n");
            return e_failur;
        }
        else
        {
            printf("File Open: %s : Success\n", argv[1]);
            return e_success;
        }
    }
    else
    {
        return e_failur;
    }
}
/* Standard C Key Words : 32 */
char keys[32][10] = {"auto", "break", "case", "char", "const", "continue", "default",
                     "do", "double", "else", "enum", "extern", "float", "for", "goto",
                     "if", "int", "long", "register", "return", "short", "signed",
                     "sizeof", "static", "struct", "switch", "typedef", "union",
                     "unsigned", "void", "volatile", "while"};

/* Function Definition LEX_Analyzer */
status lex_analyzer(char *argv[])
{
    char ch, str[25], seps[15] = " \t\n,;(){}[]#\"<>", oper[] = "!%^&*-+=~|.<>/?";
    int j;

    while ((ch = fgetc(fptr)) != EOF)
    {
        for (j = 0; j <= 14; j++)
        {
            if (ch == oper[j])
            {
                printf("Operator\t: %c\n", ch);

                str[i] = '\0';
                keywords(str);
            }
        }

        for (j = 0; j <= 14; j++)
        {
            if (i == -1)
                break;
            if (ch == seps[j])
            {
                if (ch == '#')
                {
                    printf("Header File\t: ");
                    while (ch != '>')
                    {
                        printf("%c", ch);
                        ch = fgetc(fptr);
                    }
                    printf("%c\n", ch);
                    i = -1;
                    break;
                }
                if (ch == '"')
                {
                    printf("Literal \t: \"");
                    do
                    {
                        ch = fgetc(fptr);
                        printf("%c", ch);
                    } while (ch != '"');
                    printf("\n");
                    i = -1;
                    break;
                }
                str[i] = '\0';
                keywords(str);
            }
        }
        if (i != -1)
        {
            str[i] = ch;
            i++;
        }
        else
            i = 0;
    }
    return e_success;
}
/* Function definition of Keyword */
void keywords(char *p)
{
    int k, flag = 0;
    for (k = 0; k <= 31; k++)
    {
        if (strcmp(keys[k], p) == 0)
        {
            printf("keyword         : %s\n", p);

            flag = 1;
            break;
        }
    }
    if (flag == 0)
    {
        if (isdigit(p[0]))
        {
            printf("Operands \t: %s\n", p);
        }
        else
        {
            if (p[0] != '\0')
            {
                printf("Identifier\t: %s\n", p);
            }
        }
    }
    i = -1;
}