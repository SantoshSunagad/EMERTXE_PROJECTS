#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int i;
FILE *fptr;

typedef enum st
{
    e_success,
    e_failur
} status;

status read_and_validation(char *argv[]);
status lex_analyzer(char *argv[]);
void keywords(char *p);

#endif